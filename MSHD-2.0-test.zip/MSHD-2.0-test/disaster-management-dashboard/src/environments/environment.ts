
export const environment = {
  production: false,
  codecApiUrl: 'http://localhost:8000/api',
  disasterApiUrl: 'http://localhost:8001/api',
};
