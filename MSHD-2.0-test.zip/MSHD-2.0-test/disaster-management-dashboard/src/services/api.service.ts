import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of, forkJoin, map, catchError } from 'rxjs';
import { environment } from '../environments/environment';

// Mock data models - In a real app, these would be in separate model files
export interface DisasterRecord {
  id: string;
  time: string;
  location: string;
  lat: number;
  lng: number;
  disasterType: string;
  disasterCategory: 'Geological' | 'Meteorological' | 'Flood' | 'Other';
  source: string;
  carrier: string;
  intensity: number;
  loss: string;
  media: { type: 'image' | 'video', url: string }[];
}

export interface StatItem {
  name: string;
  value: number;
}

export interface RecentPoint {
  time: string;
  count: number;
}

export interface DashboardSummary {
  total: number;
  newLast24h: number;
  pending: number;
  ingestErrors: number;
}

// ===== 新增：监控页数据模型（由后端 /api/monitoring/overview 提供）=====
export interface MonitoringDataSource {
  name: string;
  lastReceived: string;
  count24h: number;
  count7d: number;
  errors: number;
}

export interface MonitoringApiCall {
  endpoint: string;
  caller: string;
  requests: number;
  avgResponse: string;
  errorRate: string;
}

export interface MonitoringOverview {
  dataSources: MonitoringDataSource[];
  apiCalls: MonitoringApiCall[];
}

export interface DisasterQueryOptions {
  limit?: number;
  skip?: number;
  start?: string | Date; // ISO string or Date
  end?: string | Date;   // ISO string or Date
}
export interface MonitoringDataSource {
  name: string;
  lastReceived: string;
  count24h: number;
  count7d: number;
  errors: number;
}

export interface MonitoringApiCall {
  endpoint: string;
  caller: string;
  requests: number;
  avgResponse: string;
  errorRate: string;
}

export interface MonitoringOverview {
  dataSources: MonitoringDataSource[];
  apiCalls: MonitoringApiCall[];
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private http = inject(HttpClient);

  private codecBaseUrl = new URL(environment.codecApiUrl).origin;
  private disasterBaseUrl = new URL(environment.disasterApiUrl).origin;


  // This method calculates stats on the frontend based on the full data list.
  // For large datasets, it's better to have a dedicated backend endpoint for stats.
  getDashboardStats(): Observable<any> {
    const summary$ = this.http.get<DashboardSummary>(`${this.disasterBaseUrl}/api/dashboard/summary`).pipe(
      catchError(err => {
        console.error('Failed to fetch dashboard summary:', err);
        return of({ total: 0, newLast24h: 0, pending: 0, ingestErrors: 0 } as DashboardSummary);
      })
    );

    const category$ = this.http.get<StatItem[]>(`${this.disasterBaseUrl}/api/dashboard/disaster-category-distribution`).pipe(
      catchError(err => {
        console.error('Failed to fetch category distribution:', err);
        return of([] as StatItem[]);
      })
    );

    const source$ = this.http.get<StatItem[]>(`${this.disasterBaseUrl}/api/dashboard/source-distribution`).pipe(
      catchError(err => {
        console.error('Failed to fetch source distribution:', err);
        return of([] as StatItem[]);
      })
    );

    const recent$ = this.http.get<RecentPoint[]>(
      `${this.disasterBaseUrl}/api/dashboard/recent-activity`,
      { params: new HttpParams().set('hours', '72') }
    ).pipe(
      catchError(err => {
        console.error('Failed to fetch recent activity:', err);
        return of([] as RecentPoint[]);
      })
    );

    return forkJoin({ summary: summary$, category: category$, source: source$, recent: recent$ }).pipe(
      map(({ summary, category, source, recent }) => ({
        totalCount: summary.total,
        newLast24h: summary.newLast24h,
        pending: summary.pending,
        ingestErrors: summary.ingestErrors,
        disasterDistribution: {
          labels: category.map(x => x.name),
          data: category.map(x => x.value),
        },
        sourceDistribution: {
          labels: source.map(x => x.name),
          data: source.map(x => x.value),
        },
        recentActivity: {
          labels: recent.map(x => x.time),
          data: recent.map(x => x.count),
        },
      })),
      catchError(err => {
        console.error('Failed to build dashboard stats:', err);
        return of({
          totalCount: 0,
          newLast24h: 0,
          pending: 0,
          ingestErrors: 0,
          disasterDistribution: { labels: [], data: [] },
          sourceDistribution: { labels: [], data: [] },
          recentActivity: { labels: [], data: [] },
        });
      })
    );
  }

  /**
   * Fetches disaster records (from DB via main.py).
   * Backend: GET /api/public/disaster-records
   * Supports: limit/skip/start/end
   */
  getDisasterRecords(options?: DisasterQueryOptions): Observable<DisasterRecord[]> {
    let params = new HttpParams()
      .set('limit', String(options?.limit ?? 1000))
      .set('skip', String(options?.skip ?? 0));

    const toIso = (v: string | Date) => (v instanceof Date ? v.toISOString() : v);

    if (options?.start) params = params.set('start', toIso(options.start));
    if (options?.end) params = params.set('end', toIso(options.end));

    return this.http.get<DisasterRecord[]>(
      `${this.disasterBaseUrl}/api/public/disaster-records`,
      { params }
    ).pipe(
      map(records => (records || []).map(r => ({
        ...r,
        carrier: (r as any).carrier ?? '',
        intensity: (r as any).intensity ?? 0,
        loss: (r as any).loss ?? '',
        media: (r as any).media ?? [],
      }))),
      catchError(err => {
        console.error('Failed to fetch disaster records:', err);
        return of([] as DisasterRecord[]);
      })
    );
  }

  /**
   * Fetch a single disaster record (simplified) by id (from DB via main.py).
   * Backend: GET /api/public/disaster-records/{record_id}
   */
  getDisasterRecordById(recordId: string): Observable<DisasterRecord | null> {
    const safeId = encodeURIComponent(recordId);

    return this.http.get<DisasterRecord>(
      `${this.disasterBaseUrl}/api/public/disaster-records/${safeId}`
    ).pipe(
      map(r => ({
        ...r,
        carrier: (r as any).carrier ?? '',
        intensity: (r as any).intensity ?? 0,
        loss: (r as any).loss ?? '',
        media: (r as any).media ?? [],
      })),
      catchError(err => {
        console.error('Failed to fetch disaster record by id:', err);
        return of(null);
      })
    );
  }

  /**
   * Monitoring overview (now backed by DB aggregation).
   * Backend: GET /api/monitoring/overview
   * If backend fails, fallback to previous mocked data to keep UI alive.
   */
  // getMonitoringData(): Observable<MonitoringOverview> {
  //   return this.http.get<MonitoringOverview>(`${this.disasterApiUrl}/api/monitoring/overview`).pipe(
  //     catchError(err => {
  //       console.error('Failed to fetch monitoring overview:', err);

  //       // fallback: previous mock
  //       return of({
  //         dataSources: [
  //           { name: '前方指挥部', lastReceived: '2024-07-30 14:30', count24h: 1, count7d: 5, errors: 0 },
  //           { name: '舆情感知', lastReceived: '2024-07-30 08:15', count24h: 2, count7d: 12, errors: 1 },
  //           { name: '气象预警', lastReceived: '2024-07-29 18:00', count24h: 0, count7d: 3, errors: 0 },
  //           { name: '无人机勘测', lastReceived: '2024-07-28 11:45', count24h: 0, count7d: 2, errors: 0 },
  //         ],
  //         apiCalls: [
  //           { endpoint: '/api/ingest', caller: '数据采集模块', requests: 1250, avgResponse: '15ms', errorRate: '0.2%' },
  //           { endpoint: '/api/codec/decode', caller: '数据展示模块', requests: 8730, avgResponse: '5ms', errorRate: '0.01%' },
  //           { endpoint: '/api/storage/disaster-records', caller: '内部服务', requests: 450, avgResponse: '8ms', errorRate: '0.0%' },
  //         ]
  //       } as MonitoringOverview);
  //     })
  //   );
  // }
  getMonitoringData(): Observable<MonitoringOverview> {
    return this.http
      .get<MonitoringOverview>(`${this.disasterBaseUrl}/api/monitoring/overview`)
      .pipe(
        catchError(err => {
          console.error('Failed to fetch monitoring overview:', err);
          return of({ dataSources: [], apiCalls: [] } as MonitoringOverview);
        })
      );
  }

  getDictionaryData(): Observable<any> {
    const source$ = this.http.get<{code: string, name: string}[]>(`${this.codecBaseUrl}/dict/source`);
    const carrier$ = this.http.get<{code: string, name: string}[]>(`${this.codecBaseUrl}/dict/carrier`);
    const disaster$ = this.http.get<{code: string, name: string}[]>(`${this.codecBaseUrl}/dict/disaster`);

    return forkJoin({
      source: source$,
      carrier: carrier$,
      disaster: disaster$
    }).pipe(
      catchError(err => {
        console.error('Failed to fetch dictionary data:', err);
        return of({ source: [], carrier: [], disaster: [] }); // Return empty data on error
      })
    );
  }

  checkBackendStatus(): Observable<{ codec: string, disaster: string }> {
    // Construct the base URLs from the environment config to be more robust.
    const codecBaseUrl = new URL(this.codecBaseUrl).origin; // e.g., "http://localhost:8000"
    const disasterBaseUrl = new URL(this.disasterBaseUrl).origin; // e.g., "http://localhost:8001"

    // Check the /health endpoint for the codec service.
    const codecStatus$ = this.http.get(`${codecBaseUrl}/health`, { responseType: 'text' }).pipe(
      map(() => 'Online'),
      catchError(() => of('Offline'))
    );

    const disasterStatus$ = this.http.get(`${disasterBaseUrl}/health`, { responseType: 'json' }).pipe(
      map(() => 'Online'),
      catchError(() => of('Offline'))
    );

    return forkJoin({
      codec: codecStatus$,
      disaster: disasterStatus$
    });
  }
}
