import { Component, ChangeDetectionStrategy, afterNextRender, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService, DisasterRecord } from '../../services/api.service';

declare var L: any;

@Component({
  selector: 'app-map-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './map-view.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MapViewComponent {
  private apiService = inject(ApiService);
  private map: any;

  private categoryColors: Record<string, string> = {
    'Geological': '#F97316',
    'Meteorological': '#3B82F6',
    'Flood': '#10B981',
    'Other': '#6B7280',
  };

  constructor() {
    afterNextRender(() => {
      this.initMap();
      this.loadDisasterPoints();
    });
  }

  private initMap(): void {
    this.map = L.map('map', {
      center: [34.0, 108.0],
      zoom: 5
    });

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 19
    }).addTo(this.map);
    this.addLegend();
    
  }

  private loadDisasterPoints(): void {
    this.apiService.getDisasterRecords({ limit: 2000 }).subscribe(records => {
      records
        // 后端缺少坐标时会返回 0,0，地图页应过滤掉 :contentReference[oaicite:6]{index=6}
        .filter(r => this.isValidCoord(r))
        .forEach(r => this.addMarker(r));
    });
  }

  private isValidCoord(record: DisasterRecord): boolean {
    const { lat, lng } = record;

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return false;
    if (lat === 0 && lng === 0) return false; // 过滤默认值
    if (lat < -90 || lat > 90) return false;
    if (lng < -180 || lng > 180) return false;

    return true;
  }

  private addMarker(record: DisasterRecord): void {
    const color = this.categoryColors[record.disasterCategory] || '#FFFFFF';
    const radius = 5 + record.intensity;

    const marker = L.circleMarker([record.lat, record.lng], {
      radius,
      fillColor: color,
      color: "#fff",
      weight: 1,
      opacity: 1,
      fillOpacity: 0.7
    }).addTo(this.map);

    const popupContent = `
      <div class="text-gray-200">
        <h3 class="font-bold text-lg mb-2 border-b border-gray-600 pb-1">${record.disasterType} - ${record.location}</h3>
        <p><strong>时间:</strong> ${record.time}</p>
        <p><strong>来源:</strong> ${record.source}</p>
        <p><strong>损失:</strong> ${record.loss}</p>
        <p><strong>烈度:</strong> ${record.intensity}</p>
      </div>
    `;

    marker.bindPopup(popupContent);
  }

  private addLegend(): void {
  const legend = L.control({ position: 'bottomright' });

  legend.onAdd = () => {
    const div = L.DomUtil.create('div', 'bg-gray-900/80 text-gray-200 p-3 rounded text-sm');
    const items = [
      { name: 'Geological', color: this.categoryColors['Geological'] },
      { name: 'Meteorological', color: this.categoryColors['Meteorological'] },
      { name: 'Flood', color: this.categoryColors['Flood'] },
      { name: 'Other', color: this.categoryColors['Other'] },
    ];

    div.innerHTML = `<div class="font-semibold mb-2">灾害类别</div>` + items.map(i => `
      <div style="display:flex;align-items:center;gap:8px;margin:4px 0;">
        <span style="display:inline-block;width:10px;height:10px;border-radius:9999px;background:${i.color};"></span>
        <span>${i.name}</span>
      </div>
    `).join('');

    return div;
  };

  legend.addTo(this.map);
  }

}
