# app/main.py
"""
FastAPI 应用入口
负责：
1. 创建数据库表
2. 定义路由（多源接入 / 存储 / 生命周期管理相关接口）
3. 提供给前端或其它模块调用的 HTTP API
"""
from typing import List, Optional
from datetime import datetime, timedelta
import csv
from io import StringIO

from pydantic import BaseModel
from fastapi import FastAPI, Depends, UploadFile, File, HTTPException, Body, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, case
from starlette.middleware.cors import CORSMiddleware

from .database import Base, engine, get_db
from . import models, schemas
from . import ingestion_service
from .settings import RETENTION_INACTIVE_DAYS

# 在应用启动时根据 ORM 模型创建表（如果表不存在）
Base.metadata.create_all(bind=engine)

# 创建 FastAPI 实例
app = FastAPI(title="多源灾情数据管理服务（模块3&4）", version="1.0.0")

origins = [
    "http://localhost:3000",
    "http://localhost:4200",
]

# 3. 将 CORS 中间件添加到您的应用中
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,       # 允许访问的源
    allow_credentials=True,      # 支持 cookie
    allow_methods=["*"],         # 允许所有方法 (GET, POST, etc.)
    allow_headers=["*"],         # 允许所有请求头
)

# ========== 模块 3：多源数据接入与校验 ==========

@app.post("/api/ingest", response_model=schemas.IngestResponse)
def ingest_data(
    mode: str = Query(..., description="数据模式：encoded（已编码）或 raw（原始结构化）"),
    body: dict = Body(..., description="根据 mode 不同，结构不同"),
    db: Session = Depends(get_db),
):
    """
    多源数据接入接口（统一入口）
    - mode = encoded：上游已经生成统一 ID
    - mode = raw    ：上游提供原始结构化信息，需要本模块调用编码内核生成 ID
    """
    if mode == "encoded":
        payload = schemas.IngestEncodedRequest(**body)
        status, msg = ingestion_service.ingest_encoded(db, payload)
        if status != "ok":
            raise HTTPException(status_code=400, detail=msg)
        return schemas.IngestResponse(id=payload.id, status="ok", message=msg)

    elif mode == "raw":
        req = schemas.IngestRawRequest(**body)
        status, msg, new_id = ingestion_service.ingest_raw(db, req)
        if status != "ok":
            raise HTTPException(status_code=400, detail=msg)
        return schemas.IngestResponse(id=new_id, status="ok", message=msg)

    else:
        raise HTTPException(status_code=400, detail="mode 只能为 'encoded' 或 'raw'")


@app.post("/api/ingest/batch", response_model=schemas.IngestResponse)
async def ingest_batch(
    mode: str = Query(..., description="数据模式：encoded 或 raw"),
    file: UploadFile = File(..., description="CSV 文件，编码为 UTF-8"),
    db: Session = Depends(get_db),
):
    """
    批量导入接口（实验版实现为 CSV 文件）。
    """
    if file.content_type not in (
        "text/csv",
        "application/vnd.ms-excel",
        "application/octet-stream",
    ):
        raise HTTPException(status_code=400, detail="目前仅支持 CSV 文件")

    content = await file.read()
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="CSV 文件需要使用 UTF-8 编码")

    reader = csv.DictReader(StringIO(text))

    count_ok = 0
    count_err = 0

    for row in reader:
        try:
            if mode == "encoded":
                payload = schemas.IngestEncodedRequest(
                    id=row["id"],
                    value=float(row["value"]) if row.get("value") else None,
                    unit=row.get("unit"),
                    media_path=row.get("media_path"),
                    raw_payload=row.get("raw_payload"),
                )
                status, msg = ingestion_service.ingest_encoded(db, payload)
                if status == "ok":
                    count_ok += 1
                else:
                    count_err += 1

            elif mode == "raw":
                event_time = datetime.fromisoformat(row["event_time"])
                req = schemas.IngestRawRequest(
                    event=schemas.IngestRawEventInfo(
                        location_code=row["location_code"],
                        event_time=event_time,
                        source_code=row["source_code"],
                        carrier_code=row["carrier_code"],
                        disaster_category_code=row["disaster_category_code"],
                        disaster_sub_category_code=row["disaster_sub_category_code"],
                        indicator_code=row["indicator_code"],
                        value=float(row["value"]) if row.get("value") else None,
                        unit=row.get("unit"),
                        media_path=row.get("media_path"),
                        raw_payload=row.get("raw_payload"),
                    )
                )
                status, msg, _ = ingestion_service.ingest_raw(db, req)
                if status == "ok":
                    count_ok += 1
                else:
                    count_err += 1

            else:
                raise HTTPException(status_code=400, detail="mode 只能为 'encoded' 或 'raw'")

        except Exception:
            count_err += 1

    return schemas.IngestResponse(
        id="",
        status="ok",
        message=f"批量导入完成：成功 {count_ok} 条，失败 {count_err} 条",
    )


# ========== 模块 4：灾情数据存储与生命周期管理 ==========

@app.post("/api/storage/disaster-records", response_model=schemas.DisasterRecordRead)
def create_disaster_record(
    record: schemas.DisasterRecordCreate,
    db: Session = Depends(get_db),
):
    existing = db.query(models.DisasterRecord).filter(
        models.DisasterRecord.id == record.id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="记录已存在")

    obj = models.DisasterRecord(
        **record.dict(),
        created_at=datetime.utcnow(),
        last_accessed_at=datetime.utcnow(),
    )
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@app.get("/api/storage/disaster-records", response_model=List[schemas.DisasterRecordRead])
def list_disaster_records(
    skip: int = Query(0, ge=0, description="跳过多少条记录（用于分页）"),
    limit: int = Query(1000, ge=1, le=5000, description="返回多少条记录（用于分页）"),
    include_archived: bool = Query(False, description="是否包含已归档记录"),
    start: Optional[datetime] = Query(None, description="筛选起始时间（ISO8601）"),
    end: Optional[datetime] = Query(None, description="筛选结束时间（ISO8601，左闭右开）"),
    db: Session = Depends(get_db),
):
    q = db.query(models.DisasterRecord)

    if hasattr(models.DisasterRecord, "is_archived") and not include_archived:
        q = q.filter(models.DisasterRecord.is_archived == False)

    time_col = None
    if hasattr(models.DisasterRecord, "event_time"):
        time_col = models.DisasterRecord.event_time
    elif hasattr(models.DisasterRecord, "created_at"):
        time_col = models.DisasterRecord.created_at

    if time_col is not None:
        if start is not None:
            q = q.filter(time_col >= start)
        if end is not None:
            q = q.filter(time_col < end)
        q = q.order_by(time_col.desc())

    return q.offset(skip).limit(limit).all()


@app.get("/api/storage/disaster-records/{record_id}", response_model=schemas.DisasterRecordRead)
def get_disaster_record(
    record_id: str,
    db: Session = Depends(get_db),
):
    obj = db.query(models.DisasterRecord).filter(
        models.DisasterRecord.id == record_id
    ).first()
    if obj is None:
        raise HTTPException(status_code=404, detail="记录不存在")

    obj.last_accessed_at = datetime.utcnow()
    db.commit()
    db.refresh(obj)
    return obj


@app.post("/api/storage/run-retention")
def run_retention(db: Session = Depends(get_db)):
    threshold = datetime.utcnow() - timedelta(days=RETENTION_INACTIVE_DAYS)
    q = db.query(models.DisasterRecord).filter(
        models.DisasterRecord.last_accessed_at < threshold,
        models.DisasterRecord.is_archived == False,
    )
    count = q.count()

    q.update({models.DisasterRecord.is_archived: True})
    db.commit()

    return {"status": "ok", "archived_count": count}


# ========== 对外公共接口（用于前端展示） ==========

def _pick_col(*names: str):
    """从 ORM 模型中按顺序挑选第一个存在的字段列。"""
    for n in names:
        if hasattr(models.DisasterRecord, n):
            return getattr(models.DisasterRecord, n)
    return None


def _public_record_from_obj(r) -> dict:
    """把 ORM 对象映射成前端需要的简化结构。"""
    lat_key = _pick_col("lat", "latitude")
    lng_key = _pick_col("lng", "lon", "longitude")

    def _get(obj, *names, default=None):
        for n in names:
            if hasattr(obj, n):
                v = getattr(obj, n)
                if v is not None:
                    return v
        return default

    lat_val = getattr(r, lat_key.key) if lat_key is not None else None
    lng_val = getattr(r, lng_key.key) if lng_key is not None else None

    if lat_key is not None and lng_key is not None and lat_val is not None and lng_val is not None:
        lat = float(lat_val)
        lng = float(lng_val)
    else:
        lat = 0.0
        lng = 0.0

    t = _get(r, "event_time", "created_at", default="")

    return {
        "id": str(getattr(r, "id")),
        "time": str(t),
        "location": str(_get(r, "location", "location_name", "location_code", default="")),
        "lat": lat,
        "lng": lng,
        "disasterType": str(_get(r, "disaster_type", "disasterType", "disaster_sub_category_name", "disaster_sub_category_code", default="")),
        "disasterCategory": str(_get(r, "disaster_category", "disasterCategory", "disaster_category_name", "disaster_category_code", default="Other")),
        "source": str(_get(r, "source", "source_name", "source_code", default="")),
        "carrier": str(_get(r, "carrier", "carrier_name", "carrier_code", default="")),
        "intensity": int(_get(r, "intensity", "severity", "level", default=0) or 0),
        "loss": str(_get(r, "loss", "damage", default="")),
        "media": [],
    }


@app.get("/api/public/disaster-records")
def public_disaster_records(
    start: Optional[datetime] = Query(None, description="筛选起始时间（ISO8601）"),
    end: Optional[datetime] = Query(None, description="筛选结束时间（ISO8601，左闭右开）"),
    limit: int = Query(1000, ge=1, le=5000, description="最多返回多少条"),
    skip: int = Query(0, ge=0, description="跳过多少条记录（分页用）"),
    db: Session = Depends(get_db),
):
    """
    前端展示用的“简化记录列表”。
    目标：直接给总览/地图/列表提供可用字段（缺失字段会给默认值）。
    """
    time_col = _pick_col("event_time", "created_at")
    q = db.query(models.DisasterRecord)

    if hasattr(models.DisasterRecord, "is_archived"):
        q = q.filter(models.DisasterRecord.is_archived == False)

    if time_col is not None:
        if start is not None:
            q = q.filter(time_col >= start)
        if end is not None:
            q = q.filter(time_col < end)
        q = q.order_by(time_col.desc())

    rows = q.offset(skip).limit(limit).all()
    return [_public_record_from_obj(r) for r in rows]


@app.get("/api/public/disaster-records/{record_id}")
def public_disaster_record_by_id(
    record_id: str,
    db: Session = Depends(get_db),
):
    """
    前端展示用：按 id 获取单条“简化记录”。
    """
    obj = db.query(models.DisasterRecord).filter(
        models.DisasterRecord.id == record_id
    ).first()
    if obj is None:
        raise HTTPException(status_code=404, detail="记录不存在")

    # 读取也更新 last_accessed_at（复用存储层语义）
    if hasattr(obj, "last_accessed_at"):
        obj.last_accessed_at = datetime.utcnow()
        db.commit()
        db.refresh(obj)

    return _public_record_from_obj(obj)


# ========== 监控接口（用于监控页，从数据库聚合） ==========

class MonitoringDataSource(BaseModel):
    name: str
    lastReceived: str
    count24h: int
    count7d: int
    errors: int

class MonitoringApiCall(BaseModel):
    endpoint: str
    caller: str
    requests: int
    avgResponse: str
    errorRate: str

class MonitoringOverview(BaseModel):
    dataSources: List[MonitoringDataSource]
    apiCalls: List[MonitoringApiCall]

@app.get("/api/monitoring/overview", response_model=MonitoringOverview)
def monitoring_overview(db: Session = Depends(get_db)):
    """
    监控页概览数据：
    - dataSources：按来源(source/source_code/source_name)聚合，统计最近24h/7d条数、最新接收时间、错误条数
    - apiCalls：如无调用链路/日志表，这里给出一个占位结构（可后续接入真实日志）
    """
    time_col = _pick_col("event_time", "created_at")
    source_col = _pick_col("source_name", "source", "source_code")

    now = datetime.utcnow()
    t24 = now - timedelta(hours=24)
    t7d = now - timedelta(days=7)

    data_sources: List[MonitoringDataSource] = []

    if time_col is not None and source_col is not None:
        # 是否有 ingest_status 字段可用于统计错误
        has_ingest_status = hasattr(models.DisasterRecord, "ingest_status")
        ingest_status_col = getattr(models.DisasterRecord, "ingest_status", None)

        q = db.query(
            source_col.label("name"),
            func.max(time_col).label("last_received"),
            func.sum(case((time_col >= t24, 1), else_=0)).label("count_24h"),
            func.sum(case((time_col >= t7d, 1), else_=0)).label("count_7d"),
        )

        if has_ingest_status and ingest_status_col is not None:
            q = q.add_columns(
                func.sum(case((ingest_status_col == "error", 1), else_=0)).label("errors")
            )
        else:
            q = q.add_columns(func.sum(case((False, 1), else_=0)).label("errors"))

        if hasattr(models.DisasterRecord, "is_archived"):
            q = q.filter(models.DisasterRecord.is_archived == False)

        q = q.group_by(source_col).order_by(func.max(time_col).desc())

        rows = q.all()
        for row in rows:
            name = str(row[0]) if row[0] is not None else "Unknown"
            last_received = row[1]
            count_24h = int(row[2] or 0)
            count_7d = int(row[3] or 0)
            errors = int(row[4] or 0)

            data_sources.append(MonitoringDataSource(
                name=name,
                lastReceived=last_received.isoformat() if last_received else "",
                count24h=count_24h,
                count7d=count_7d,
                errors=errors,
            ))

    # apiCalls：目前项目中没有“调用日志表”，先提供占位结构，避免前端空指针
    api_calls = [
        MonitoringApiCall(endpoint="/api/ingest", caller="数据采集模块", requests=0, avgResponse="-", errorRate="-"),
        MonitoringApiCall(endpoint="/api/storage/disaster-records", caller="内部服务", requests=0, avgResponse="-", errorRate="-"),
        MonitoringApiCall(endpoint="/api/public/disaster-records", caller="数据展示模块", requests=0, avgResponse="-", errorRate="-"),
    ]

    return MonitoringOverview(dataSources=data_sources, apiCalls=api_calls)

# ======= Monitoring (for monitoring page) =======

class MonitoringDataSource(BaseModel):
    name: str
    lastReceived: str
    count24h: int
    count7d: int
    errors: int

class MonitoringApiCall(BaseModel):
    endpoint: str
    caller: str
    requests: int
    avgResponse: str
    errorRate: str

class MonitoringOverview(BaseModel):
    dataSources: List[MonitoringDataSource]
    apiCalls: List[MonitoringApiCall]


@app.get("/api/monitoring/overview", response_model=MonitoringOverview)
def monitoring_overview(db: Session = Depends(get_db)):
    """
    监控页数据（从灾情表按 source 聚合）：
    - lastReceived：最新一条记录时间
    - count24h / count7d：近 24h / 7d 条数
    - errors：当前模型未知错误字段，先返回 0（如你有字段可再改）
    """
    now = datetime.utcnow()

    source_col = _pick_col("source", "source_name", "source_code")
    time_col = _pick_col("created_at", "event_time")

    if source_col is None or time_col is None:
        return MonitoringOverview(dataSources=[], apiCalls=[])

    q = db.query(
        source_col.label("name"),
        func.max(time_col).label("last_received"),
        func.sum(case((time_col >= (now - timedelta(hours=24)), 1), else_=0)).label("count_24h"),
        func.sum(case((time_col >= (now - timedelta(days=7)), 1), else_=0)).label("count_7d"),
    )

    if hasattr(models.DisasterRecord, "is_archived"):
        q = q.filter(models.DisasterRecord.is_archived == False)

    q = q.group_by(source_col).order_by(func.count(models.DisasterRecord.id).desc())
    rows = q.all()

    data_sources = [
        MonitoringDataSource(
            name=str(r.name),
            lastReceived=r.last_received.isoformat(sep=" ", timespec="seconds") if r.last_received else "",
            count24h=int(r.count_24h or 0),
            count7d=int(r.count_7d or 0),
            errors=0,
        )
        for r in rows
    ]

    # 如果你没有 API 调用日志表，就先返回空数组；后续有表再补。
    return MonitoringOverview(dataSources=data_sources, apiCalls=[])

# ========== 对外统计接口（用于总览大屏图表） ==========

class StatItem(BaseModel):
    name: str
    value: int

class RecentPoint(BaseModel):
    time: str
    count: int

class DashboardSummary(BaseModel):
    total: int
    newLast24h: int
    pending: int
    ingestErrors: int


@app.get("/api/dashboard/summary", response_model=DashboardSummary)
def dashboard_summary(db: Session = Depends(get_db)):
    now = datetime.utcnow()

    q = db.query(models.DisasterRecord)
    if hasattr(models.DisasterRecord, "is_archived"):
        q = q.filter(models.DisasterRecord.is_archived == False)

    total = q.count()

    time_col = _pick_col("created_at", "event_time")
    new_last_24h = 0
    if time_col is not None:
        new_last_24h = q.filter(time_col >= (now - timedelta(hours=24))).count()

    pending = 0
    if hasattr(models.DisasterRecord, "status"):
        pending = q.filter(models.DisasterRecord.status == "pending").count()

    ingest_errors = 0
    if hasattr(models.DisasterRecord, "ingest_status"):
        ingest_errors = q.filter(models.DisasterRecord.ingest_status == "error").count()

    return DashboardSummary(
        total=total,
        newLast24h=new_last_24h,
        pending=pending,
        ingestErrors=ingest_errors,
    )


@app.get("/api/dashboard/disaster-category-distribution", response_model=List[StatItem])
def disaster_category_distribution(
    start: Optional[datetime] = Query(None, description="筛选起始时间（ISO8601）"),
    end: Optional[datetime] = Query(None, description="筛选结束时间（ISO8601，左闭右开）"),
    db: Session = Depends(get_db),
):
    category_col = _pick_col(
        "disaster_category", "disasterCategory",
        "disaster_category_code", "disaster_category_name",
    )
    time_col = _pick_col("event_time", "created_at")

    if category_col is None:
        return []

    q = db.query(category_col.label("name"), func.count(models.DisasterRecord.id).label("value"))

    if hasattr(models.DisasterRecord, "is_archived"):
        q = q.filter(models.DisasterRecord.is_archived == False)

    if time_col is not None:
        if start is not None:
            q = q.filter(time_col >= start)
        if end is not None:
            q = q.filter(time_col < end)

    q = q.group_by(category_col).order_by(func.count(models.DisasterRecord.id).desc())
    rows = q.all()
    return [StatItem(name=str(r.name), value=int(r.value)) for r in rows]


@app.get("/api/dashboard/source-distribution", response_model=List[StatItem])
def source_distribution(
    start: Optional[datetime] = Query(None, description="筛选起始时间（ISO8601）"),
    end: Optional[datetime] = Query(None, description="筛选结束时间（ISO8601，左闭右开）"),
    db: Session = Depends(get_db),
):
    source_col = _pick_col("source", "source_name", "source_code")
    time_col = _pick_col("event_time", "created_at")

    if source_col is None:
        return []

    q = db.query(source_col.label("name"), func.count(models.DisasterRecord.id).label("value"))

    if hasattr(models.DisasterRecord, "is_archived"):
        q = q.filter(models.DisasterRecord.is_archived == False)

    if time_col is not None:
        if start is not None:
            q = q.filter(time_col >= start)
        if end is not None:
            q = q.filter(time_col < end)

    q = q.group_by(source_col).order_by(func.count(models.DisasterRecord.id).desc())
    rows = q.all()
    return [StatItem(name=str(r.name), value=int(r.value)) for r in rows]


@app.get("/api/dashboard/recent-activity", response_model=List[RecentPoint])
def recent_activity(
    hours: int = Query(72, ge=1, le=720, description="统计最近多少小时"),
    db: Session = Depends(get_db),
):
    now = datetime.utcnow()
    time_col = _pick_col("created_at", "event_time")
    if time_col is None:
        return []

    start_time = (now - timedelta(hours=hours)).replace(minute=0, second=0, microsecond=0)

    buckets = []
    bucket_map = {}
    for i in range(hours):
        t = (start_time + timedelta(hours=i))
        bucket_map[t] = 0
        buckets.append(t)

    q = db.query(time_col).filter(time_col >= start_time, time_col < now)
    if hasattr(models.DisasterRecord, "is_archived"):
        q = q.filter(models.DisasterRecord.is_archived == False)

    for (t,) in q.all():
        if t is None:
            continue
        ht = t.replace(minute=0, second=0, microsecond=0)
        if ht in bucket_map:
            bucket_map[ht] += 1

    return [
        RecentPoint(time=f"{t.hour:02d}:00", count=bucket_map[t])
        for t in buckets
    ]


@app.get("/health")
def health():
    return {"status": "ok"}
